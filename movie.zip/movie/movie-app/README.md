Movie award nomination site for entrepreneurs. Users can search for movies and also nominate movies

# movie-app
